<?php
    require_once 'header.php';
?>
<html>
<head>
<link rel="stylesheet" href="CSS/mystyle.css">
</head>
<body>
<h2 class="head2" align="middle">SERVICES</h2>
<div class="app" align="middle">Services 1</div>
<div class="app" align="middle">Services 2</div>
<div class="app" align="middle">Services 3</div>

    <div class="gap">
        &nbsp
        </div>
</body>
</html>
<?php
    require_once 'footer.php';
?>