<?php
    require_once 'header.php';
?>
<html>
<head>
<link rel="stylesheet" href="CSS/mystyle.css">
</head>
<body>
<h2 class="head2" align="middle">ABOUT</h2>

<p class="aboutDes">Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and scrambled it to make a type specimen book. 
It has survived not only five centuries, but also the leap into electronic typesetting, 
remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset 
sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like 
Aldus PageMaker including versions of Lorem Ipsum.</p>


<fieldset style="background-color:rgb(77, 166, 255);">
<table>
<tr>
<td>
<img src="images/logo.png" height="40px" width="200px">
<pre style="font-family:calibri; font-size:20px;">
Lorem Ipsum is simply dummy text of the printing
and typesetting industry. Lorem Ipsum has been the 
industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and 
scrambled it to make a type specimen book. It has 
survived not only five centuries, but also the 
leap into electronic typesetting, remaining 
essentially unchanged.
</pre>
</td>
<td style="padding-left:100px">
</td>
<td>
CONTACT US<br><br>
<img style="display:inline" src="images/location.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Dhaka</span><br>
<img style="display:inline" src="images/telephone.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">+8801732739957</span><br>
<img style="display:inline" src="images/gmail.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">xyz@gmail.com</span>
</td>
<td style="padding-left:100px">
</td>
<td>
<div style="width: 100%"><iframe width="200" height="250" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=200&amp;height=200&amp;hl=en&amp;q=Dhaka,%20Bangladesh+(ddportal)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://www.maps.ie/draw-radius-circle-map/"></a></div>
</td>
<td style="padding-left:100px">
</td>
<td>
FOLLOW US<br><br>
<img style="display:inline" src="images/facebook.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Facebook</span><br>
<img style="display:inline" src="images/twitter.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Twitter</span><br>
<img style="display:inline" src="images/linkedin.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Linkedin</span>
</td>
</tr>
</table>
</fieldset>
<div class="gap">
        &nbsp
        </div>
</body>
</html>
<?php
    require_once 'footer.php';
?>