<html>
<body style="background-color:cyan;">
<a href="index.php"><img src="images/logo.png" height="40px" width="200px"></a>
</body>
</html>