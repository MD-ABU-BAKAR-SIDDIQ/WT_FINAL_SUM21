<html>
<head>
<script>
	 function view(){
		 alert("Login Frist!");
	 } 
</script>
<style>
.head{
	text-decoration:none;
	font: small-caps bold 12px/30px Georgia, serif;
	font-size: 20px;
	padding-right:20px;
	padding-left:20px;
	//background-color:rgb(102, 153, 153);
	border-radius:5px;
	color:rgb(0, 77, 77);	
}
.head:hover{
	background-color:rgb(117, 163, 163);
}
#title{
	font-size: 40px;
	font-family:fantasy;
	text-align: center;
	color:rgb(0, 128, 128);
}
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 30%;
}
.app{
	font-size:30px;
	color:white;
	font-family:calibri;
	padding-left:40px;
	padding-right:40px;
	padding-top:20px;
	padding-bottom:20px;
	text-decoration:none;
	border-radius:5px;
	background-color:rgb(77, 77, 255);
}
.app:hover{
	background-color:rgb(0,78,162);
}
.gap{
	padding-top:40px;
	padding-bottom:40px;
}
.head2{
	font-size:35px;
	background-color:rgb(77, 166, 255);
	
}
.head3{
	font-size:25px;
}
</style>
</head>
<body style="background-color:cyan;">

<a href="index.php"><img src="images/logo.png" height="40px" width="200px"></a>
<table style="display:inline;" align="right">
<tr>
<td>
<a class="head" href="index.php">Home</a>
<a class="head" href="services.php" target="_blank">Services</a>
<a class="head" href="about.php" target="_blank">About Us<a/>
<a class="head" href="contact.php" target="_blank">Contact Us</a>
<a class="head" href="login.php" target="_blank">Login</a>
</td>
</tr>
</table>

<p id="title">Doctor Patient Portal</p>
<img src="images/index.png" class="center">

<div align="middle"><button class="app" onclick="view()"><a style="text-decoration:none;" href="login.php" target="_blank">Appointment</a></button></div>
<div class="gap">
&nbsp
</div>
<h2 class="head2" align="middle">WHAT CLIENT SAY</h2>
<table>
<tr>
<td colspan="2">Web technology is the development of the mechanism that allows two of more computer devices to communicate over a network.</td>
<td colspan="2">Web technology is the development of the mechanism that allows two of more computer devices to communicate over a network.</td>
<td colspan="2">Web technology is the development of the mechanism that allows two of more computer devices to communicate over a network.</td>
</tr>
<tr>
<td><img src="images/client1.png" height="100" width="100"></td><td><b>Rakib Hasan</b><br>Student of AIUB</td>
<td><img src="images/client2.png" height="100" width="100"></td><td><b>Mushfiq Alam</b><br>Student of AIUB</td>
<td><img src="images/client3.png" height="100" width="100"></td><td><b>Siddiq Arman</b><br>Student of AIUB</td>
</tr>
</table>
<div class="gap">
&nbsp
</div>
<h2 class="head2" align="middle">WHY CHOOSE US?</h2>


<table style="display:inline">
<tr>
<td class="head3">
Why we're different:<br><br>
Lorem Ipsum is simply dummy text of the printing and typesetting industry<br>
Lorem Ipsum is simply dummy text of the printing and typesetting industry<br>
Lorem Ipsum is simply dummy text of the printing and typesetting industry<br>
Lorem Ipsum is simply dummy text of the printing and typesetting industry<br>
Lorem Ipsum is simply dummy text of the printing and typesetting industry<br>
</td>
</tr>
</table>
<table align="right" style="display:inline">
<tr>
<td><img src="images/diagram.png"  height="200px" width="200px"></td>
<td style="padding-right:70px"></td>
</tr>
</table>
<div class="gap">
&nbsp
</div>
<fieldset style="background-color:rgb(77, 166, 255);">
<table>
<tr>
<td>
<img src="images/logo.png" height="40px" width="200px">
<pre style="font-family:calibri; font-size:20px;">
Lorem Ipsum is simply dummy text of the printing
and typesetting industry. Lorem Ipsum has been the 
industry's standard dummy text ever since the 1500s, 
when an unknown printer took a galley of type and 
scrambled it to make a type specimen book. It has 
survived not only five centuries, but also the 
leap into electronic typesetting, remaining 
essentially unchanged.
</pre>
</td>
<td style="padding-left:100px">
</td>
<td>
CONTACT US<br><br>
<img style="display:inline" src="images/location.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Dhaka</span><br>
<img style="display:inline" src="images/telephone.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">+8801732739957</span><br>
<img style="display:inline" src="images/gmail.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">xyz@gmail.com</span>
</td>
<td style="padding-left:100px">
</td>
<td>
<div style="width: 100%"><iframe width="200" height="250" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?width=200&amp;height=200&amp;hl=en&amp;q=Dhaka,%20Bangladesh+(ddportal)&amp;t=&amp;z=14&amp;ie=UTF8&amp;iwloc=B&amp;output=embed"></iframe><a href="https://www.maps.ie/draw-radius-circle-map/"></a></div>
</td>
<td style="padding-left:100px">
</td>
<td>
FOLLOW US<br><br>
<img style="display:inline" src="images/facebook.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Facebook</span><br>
<img style="display:inline" src="images/twitter.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Twitter</span><br>
<img style="display:inline" src="images/linkedin.png" height="30px" width="30px"><span style="font-family:Comic Sans; font-size:20px;">Linkedin</span>
</td>
</tr>
</table>
</fieldset>
<hr><p align="middle">Copyright@2021 | Doctor Patient Portal | All Rights Reserved</p></hr>
</body>
</html>