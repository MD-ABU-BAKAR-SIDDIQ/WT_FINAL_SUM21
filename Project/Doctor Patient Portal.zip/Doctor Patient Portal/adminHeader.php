<html>
<head>
<link rel="stylesheet" href="CSS/mystyle.css">
<style>

</style>
</head>
<body style="background-color:cyan;">
<a href="index.php"><img src="images/logo.png" height="40px" width="200px"></a>

<span style="padding-right:120px;">&nbsp</span>
<a class="head" href="adminProfile.php">Profile</a>
<a class="head" href="appointment.php" >Appointment</a>
<a class="head" href="allDoctorList.php" >Doctors<a/>
<a class="head" href="doctorRequest.php" >Doctors Request</a>
<a class="head" href="allPatientList.php" >Patients</a>
<a class="head" href="allDonorList.php" >Donors</a>
<a class="head" href="userContact.php" >Messages</a>
<a class="head" href="login.php" ><img src="images/logout.png" height="20px" width="20px"></a>

</body>
</html>