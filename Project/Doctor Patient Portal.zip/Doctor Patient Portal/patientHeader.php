<html>
<head>
<link rel="stylesheet" href="CSS/mystyle.css">
<style>

</style>
</head>
<body style="background-color:cyan;">
<a href="index.php"><img src="images/logo.png" height="40px" width="200px"></a>

<span style="padding-right:670px;">&nbsp</span>
<a class="head" href="patientProfile.php">Profile</a>
<a class="head" href="viewAppByPatient.php" >Appointment</a>
<a class="head" href="viewBlood.php" >Blood</a>
<a class="head" href="login.php" ><img src="images/logout.png" height="20px" width="20px"></a>

</body>
</html>