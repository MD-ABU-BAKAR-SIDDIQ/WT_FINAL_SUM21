<html>
<body>
Admin has been added successfully. <a href="suadmin.php">To add more</a>
</body>
</html>