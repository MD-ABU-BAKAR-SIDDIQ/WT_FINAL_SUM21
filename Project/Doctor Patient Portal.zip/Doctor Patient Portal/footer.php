<html>
<body>
<hr><p align="middle">Copyright@2021 | Doctor Patient Portal | All Rights Reserved</p></hr>
</body>
</html>
